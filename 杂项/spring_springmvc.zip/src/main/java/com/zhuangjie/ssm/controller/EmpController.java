package com.zhuangjie.ssm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;

@Controller
@RequestMapping("/emp")
public class EmpController {

    @RequestMapping("/demo")
    public ModelAndView demo() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("date",new Date());
        modelAndView.setViewName("success");
        return modelAndView;
    }
}
