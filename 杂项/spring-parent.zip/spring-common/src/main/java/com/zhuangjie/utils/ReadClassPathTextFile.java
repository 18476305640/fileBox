package com.zhuangjie.utils;

import java.io.InputStream;
import java.util.Scanner;


public class ReadClassPathTextFile {
    /**
     * 读取类路径下的文件即可以读取resources目录下的文件
     * 示例
     *         String read = ReadClassPathTextFile.read("/auth_key/id_key_rsa");
     *         System.out.println(read);
     * @param clashpath
     * @return
     */
    public static String read(String clashpath) {
        InputStream resourceAsStream = ReadClassPathTextFile.class.getResourceAsStream(clashpath);
        Scanner s = new Scanner(resourceAsStream).useDelimiter("\\A");
        String text_string = s.hasNext() ? s.next() : "";
        return text_string;
    }

    public static byte[] readReturnByte(String clashpath) {
        String text_string = ReadClassPathTextFile.read(clashpath);
        byte[] bytes = text_string.getBytes();
        return bytes;
    }
}
