import com.zhuangjie.common.RsaUtils;
import com.zhuangjie.utils.ReadClassPathTextFile;
import org.junit.Test;
import org.mockito.internal.util.StringUtil;

import java.io.*;
import java.lang.reflect.Array;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MyTest {
    private String publicFilePath = "C:\\Users\\zhuangjie\\auth_key\\id_key_rsa.pub";
    private String privateFilePath = "C:\\Users\\zhuangjie\\auth_key\\id_key_rsa";



    @Test
    public void generateKey() throws Exception {
        RsaUtils.generateKey(publicFilePath, privateFilePath, "zjazn", 2048);
    }

    @Test
    public void getPublicKey() throws Exception {
        System.out.println(RsaUtils.getPublicKey(publicFilePath));
    }

    @Test
    public void getPrivateKey() throws Exception {
        System.out.println(RsaUtils.getPrivateKey(privateFilePath));
    }

//    @Test
//    public void test() {
//        try {
//            RsaUtils.generateKey(publicFilePath,privateFilePath,"zjazn",2048);
//        } catch (Exception e) {
//            System.out.printf("Gen errored~");
//            e.printStackTrace();
//        }
//    }
//    @Test
//    public void test02 () {
//        String sepa = java.io.File.separator;
////        System.out.println(sepa);
////        System.out.println(publicKeyPathAndName);
//
////        String path = publicKeyPathAndName.substring(0,publicKeyPathAndName.lastIndexOf(sepa));
////        System.out.println(path);
//        RsaUtils.checkPathExist(publicKeyPathAndName);
//
//
//    }

    @Test
    public void test() {
        String classpath = "classpath:/auth_key/id_key_rsa";
//        String substring = classpath.trim().substring(10);
//        //系统路径分隔符
//        String sepa = java.io.File.separator;
//        System.out.println("sepa"+sepa);
//        String[] split = substring.split("/");
//        String result = "";
//        for(int i = 1; i < split.length; i++) {
//            result = result + sepa + split[i];
//        }
//
//        System.out.println(result);
        try {
            PrivateKey privateKey = RsaUtils.getPrivateKey(classpath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }



}
