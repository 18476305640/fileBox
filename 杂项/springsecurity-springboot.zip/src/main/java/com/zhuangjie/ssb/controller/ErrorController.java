package com.zhuangjie.ssb.controller;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


@ControllerAdvice
public class ErrorController {
    @ExceptionHandler(RuntimeException.class)
    public String exceptionHandle(RuntimeException e) {
        if (e instanceof AccessDeniedException) {
            return "redirect:/403.jsp";
        }
        return "redirect:/500.jsp";

    }
}
