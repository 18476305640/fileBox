package com.zhuangjie.ssm.mapper;

import com.zhuangjie.ssm.pojo.Book;

import java.util.List;

public interface BookMapper {
    List<Book> queryAllBook() throws Exception;
}
