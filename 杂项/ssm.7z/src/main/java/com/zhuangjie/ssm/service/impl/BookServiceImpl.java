package com.zhuangjie.ssm.service.impl;

import com.zhuangjie.ssm.mapper.BookMapper;
import com.zhuangjie.ssm.pojo.Book;
import com.zhuangjie.ssm.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {
    @Autowired
    public BookMapper bookMapper;

    @Override
    public List<Book> queryAllBook() throws Exception {

        return bookMapper.queryAllBook();
    }
}
