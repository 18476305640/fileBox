package com.zhuangjie.ssm.controller;

import com.zhuangjie.ssm.pojo.Book;
import com.zhuangjie.ssm.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/demo")
public class DemoController {
    @Autowired
    public BookService bookService;

    @RequestMapping("/test")
    public @ResponseBody List<Book>  test() throws Exception {
        List<Book> books = bookService.queryAllBook();
        return books;
    }
}
