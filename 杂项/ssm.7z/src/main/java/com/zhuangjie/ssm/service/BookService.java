package com.zhuangjie.ssm.service;

import com.zhuangjie.ssm.pojo.Book;

import java.util.List;

public interface BookService {
    List<Book> queryAllBook() throws Exception;
}
