package com.zhuangjie.mq.msgs;

import lombok.Data;
import lombok.ToString;

import java.io.Serializable;

@Data
@ToString
public class Email implements Serializable {
    private String addresseeEmail;
    private String msg;


}
