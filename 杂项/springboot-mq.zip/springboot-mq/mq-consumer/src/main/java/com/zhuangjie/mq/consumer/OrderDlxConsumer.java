package com.zhuangjie.mq.consumer;

import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class OrderDlxConsumer {

    /**
     * 死信队列监听队列回调的方法
     *
     * @param msg
     */

    @RabbitListener(queues = "order_dlx_queue")
    @RabbitHandler
    public void orderConsumer(String msg, Message message, Channel channel) throws IOException {
        log.info(">死信队列消费订单消息:msg{}<<", msg);

        channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
    }
}