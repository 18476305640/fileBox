package com.zhuangjie.mq.consumer;//package com.mayikt.consumer;

import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/**
 * 订单消费者
 */
@Component
@Slf4j
public class OrderConsumer {

    /**
     * 监听队列回调的方法
     *
     * @param msg
     */
    @RabbitListener(queues = "order_queue")
    @RabbitHandler
    public void orderConsumer(String msg, Message message, Channel channel) throws Exception {
//        System.out.println("死信消费者");
//        try {
//            int i = 1/0;
//        }catch (Exception e) {
//            //如果代码出错：作日志记录，之后进行定时任务、后人工补偿
//
//            //或将该消息放入死信队列中
//        }
        log.info(">>正常订单消费者消息MSG:{}<<", msg);
        channel.basicAck(message.getMessageProperties().getDeliveryTag(), false);
    }
}