package com.zhuangjie.mq.config;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.connection.CorrelationData;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

@Service
public class AckPublisher implements RabbitTemplate.ConfirmCallback, RabbitTemplate.ReturnCallback {
    @Autowired
    private RabbitTemplate rabbitTemplate;

    @PostConstruct
    public void init() {
        //设置回退消息交给谁处理
        rabbitTemplate.setReturnCallback(this);
        rabbitTemplate.setConfirmCallback(this);
        /**
         * true：
         * 交换机无法将消息进行路由时，会将该消息返回给生产者
         * false：
         * 如果发现消息无法进行路由，则直接丢弃
         */
        rabbitTemplate.setMandatory(true); //yml:publisher-returns: true配置true同等效果，二选一

    }

    /**
     * 接收发送后确认信息
     * @param correlationData 回调消息id及其余信息
     * @param ack  是否发送成功，交换机是否收到消息，true 成功 false 失败
     * @param cause 原因，ack为true则cause为空，ack为false则cause为失败原因
     */
    @Override
    public void confirm(CorrelationData correlationData, boolean ack, String cause) {
        //如果发送的是延迟消息（测试使用的插件延迟消息）correlationData是null，b是true
        if (ack) {
            System.out.println("[ _ ] ACK消息：MQ已接收");
        } else {
            System.out.println(">_<ACK消息：MQ未接收: " + correlationData + "|" + cause);
            //可以在此处写入对失败消息的处理逻辑，重新发送，还是存入数据库，等待后续发送
        }
    }

    /**
     * 发送失败的回调
     *
     * @param message
     * @param replyCode
     * @param replyText
     * @param exchange
     * @param routingKey
     */
    @Override
    public void returnedMessage(Message message, int replyCode, String replyText, String exchange, String routingKey) {
        System.out.println("ack " + message + " 发送失败");
    }




}