import axios from "axios"
import { nanoid } from 'nanoid'
export default {
    namespaced: true,	// 开启命名空间
    state: {
        //this.$store.state.personAbout.items;
        items: []
    },
    mutations: {
        /*
            this.$store.commit("personAbout/_randomItem", {
                id: nanoid(),
                name: "测试",
            });
        */
        _randomItem(state, value_item) {
            state.items.unshift(value_item)
        }
    },
    actions: {
        /*this.$store.dispatch(
            "personAbout/randomItem",
            "http://api.uixsj.cn/hitokoto/get?type=social"
        );*/
        randomItem(context, value_url) {
            console.log("target=>", value_url)
            axios.get(value_url).then(resource => {
                let item = { id: nanoid(), name: resource.data }
                context.commit('_randomItem', item)
            }, error => {
                alert("Add item faild!", error);
            })
        }
    },
    getters: {
        //this.$store.getters["personAbout/_items"];
        _items(state) {
            console.log('getters')
            return state.items
        }
    }
}