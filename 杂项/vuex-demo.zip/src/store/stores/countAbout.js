export default {
    namespaced: true,	// 开启命名空间
    state: { msg: '' },
    mutations: {
        toMsg(state, value) {
            state.msg = value
        }
    },
    actions: {

    },
    getters: {
        bigSum(state) { return state.sum * 10 }
    }
}