import Vue from 'vue'
import Vuex from 'vuex'	// 引入Vuex
Vue.use(Vuex)	// 应用Vuex插件
import countAbout from './stores/countAbout'
import personAbout from './stores/personAbout'
// 创建并暴露store
export default new Vuex.Store({
    modules: {
        countAbout, personAbout
    }
}) 