<template>
  <ul>
    <li v-for="item in items" :key="item.id">{{ item.name }}</li>
  </ul>
</template>

<script>
import { mapState, mapGetters } from "vuex";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "List",
  computed: {
    ...mapState("personAbout", ["items"]),
    ...mapGetters("personAbout", ["_items"]),
  },
};
</script>

<style scoped>
</style>