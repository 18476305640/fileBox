<template>
  <div>
    请输入：
    <button
      v-on:click="add('http://api.uixsj.cn/hitokoto/get?type=social', 'hello')"
    >
      随机添加
    </button>
  </div>
</template>

<script>
import { mapActions, mapMutations } from "vuex";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Add",
  data() {
    return {
      itemName: "",
    };
  },
  methods: {
    ...mapMutations("personAbout", { _add: "_randomItem" }),
    ...mapActions("personAbout", { add: "randomItem" }),
  },
};
</script>

<style scoped>
</style>