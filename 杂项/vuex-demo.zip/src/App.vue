<template>
  <div id="app">
    <Add />
    <List />
  </div>
</template>

<script>
import Add from "./components/Add";
import List from "./components/List";
export default {
  name: "App",
  components: { Add, List },
};
</script>

<style>
</style>
