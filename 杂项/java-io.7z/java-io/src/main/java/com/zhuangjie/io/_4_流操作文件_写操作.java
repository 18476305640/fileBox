package com.zhuangjie.io;

import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class _4_流操作文件_写操作 {
    @Test
    public void write01() {
        File file = new File("D:\\system\\文档\\mf.txt");
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(file,true);
            String msg = "在干啥？";
            fileOutputStream.write(msg.getBytes());
            fileOutputStream.flush();
        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            try {
                fileOutputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
