package com.zhuangjie.io;

import org.junit.Test;
import sun.nio.cs.ext.GBK;

import java.io.*;

public class _11_转换流 {
    public static void main(String[] args) throws IOException {
        String sourceFilePath = "D:\\system\\文档\\test.txt";
        InputStreamReader isr = new InputStreamReader(new FileInputStream(sourceFilePath), "GBK");
        BufferedReader br = new BufferedReader(isr);
        String content = br.readLine();
        System.out.println(content);



    }

    @Test
    public void main_() throws IOException {
        String sourceFilePath = "D:\\system\\文档\\test.txt";
        OutputStreamWriter osw = new OutputStreamWriter(new FileOutputStream(sourceFilePath),"GBK");
        osw.write("-你好，使用的是UTF-8！");
        osw.close();
    }
}
