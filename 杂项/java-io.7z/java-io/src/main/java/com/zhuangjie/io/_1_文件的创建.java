package com.zhuangjie.io;

import org.junit.Test;

import java.io.File;
import java.io.IOException;

public abstract class _1_文件的创建 {
    /**
     * 文件创建的三种方式
     */
    @Test
    public void test01() {
        File file = new File("D:\\system\\文档\\file01.txt");
        try {
            file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("第一种方式：文件创建成功！");


        File parentFile = new File("D:\\system\\文档");
        File file02 = new File(parentFile, "file02.txt");
        try {
            file02.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("方式二创建文件成功！");

        File file03 = new File("D:\\system\\文档", "file03.txt");
        try {
            file03.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("第三种方式文件创建成功！");
    }



}