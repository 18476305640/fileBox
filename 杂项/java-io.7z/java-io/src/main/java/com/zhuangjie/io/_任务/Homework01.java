package com.zhuangjie.io._任务;

import com.zhuangjie.io.jopo.Dog;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Homework01 {

    //文件夹创建
    @Test
    public void test01() {
        File file = new File("e:\\mytemp");
        if (!file.isDirectory()) {
            file.mkdirs();
            System.out.println("文件夹创建成功~");
        }else {
            System.out.println("目标文件夹已存在~");
        }

    }
    //properties
    @Test
    public void test02() throws IOException {
        Properties properties = new Properties();
        properties.load(new FileReader("src\\dog.properties"));

        String name = properties.getProperty("name");
        String age = properties.getProperty("age");
        Integer integer = Integer.valueOf(age);
        Dog dog = new Dog(name, integer);
        System.out.println(dog);



    }
}
