package com.zhuangjie.io;

import org.junit.Test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class _5_文件的拷贝 {
    /**
     * 文件拷贝
     * @param args
     */
    public static void main(String[] args) {
        FileInputStream fileInputStream = null;
        FileOutputStream fileOutputStream = null;
        byte[] bytes = new byte[1024];
        int readLen = 0;
        try {
            fileInputStream = new FileInputStream("D:\\system\\图片\\uToolsWallpapers\\美女.png");
            fileOutputStream = new FileOutputStream("D:\\system\\图片\\美女_clone.png");

            while ((readLen = fileInputStream.read(bytes)) > 0) {
                fileOutputStream.write(bytes, 0, readLen);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                fileInputStream.close();
                fileOutputStream.close();
            }catch (IOException e) {
                e.printStackTrace();
            }

        }
    }


}
