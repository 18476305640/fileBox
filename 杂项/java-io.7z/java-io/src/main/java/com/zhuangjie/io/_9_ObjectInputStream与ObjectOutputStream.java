package com.zhuangjie.io;

import com.zhuangjie.io._Dog;
import org.junit.Test;

import java.io.*;

public class _9_ObjectInputStream与ObjectOutputStream {
    @Test
    public void serialize() {
        ObjectOutputStream oos =  null;
        String sourceFilePath = "D:\\system\\文档\\o.dat";
        try {
            oos = new ObjectOutputStream(new FileOutputStream(sourceFilePath));
            oos.writeUTF("小庄");
            oos.writeBoolean(true);
            oos.writeInt(123); //自动装箱
            oos.writeObject(new _Dog("旺财",2));
            System.out.println("序列化完成~");
        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            try {
                oos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void unserialize() {
        ObjectInputStream ois =  null;
        String sourceFilePath = "D:\\system\\文档\\o.dat";
        try {
            ois = new ObjectInputStream(new FileInputStream(sourceFilePath));
            String sv = ois.readUTF();
            boolean b = ois.readBoolean();
            int i = ois.readInt();
            Object o = ois.readObject();
            _Dog o1 =  (_Dog)o;
            System.out.println(sv);
            System.out.println(b);
            System.out.println(i);
            System.out.println(o1);
        }catch (IOException e) {
            System.out.println(e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            try {
                ois.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

