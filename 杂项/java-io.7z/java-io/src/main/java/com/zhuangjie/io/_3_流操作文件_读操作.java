package com.zhuangjie.io;

import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class _3_流操作文件_读操作 {
    @Test
    public void read01() {
        //使用read()文件读取文件
        File file = new File("D:\\system\\文档\\Hello.txt");
        FileInputStream fileInputStream = null;
        int byteData = 0;
        try {
            fileInputStream = new FileInputStream(file);
            while ((byteData = fileInputStream.read()) != -1) {
                System.out.print((char)byteData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                fileInputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Test
    public void read02() {
        //使用read()文件读取文件
        File file = new File("D:\\system\\文档\\Hello.txt");
        FileInputStream fileInputStream = null;
        byte[] bytes = new byte[8];
        int readLen = 0;
        try {
            fileInputStream = new FileInputStream(file);
            while ((readLen = fileInputStream.read(bytes)) > 0) {
                System.out.print(new String(bytes, 0, readLen));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                fileInputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
