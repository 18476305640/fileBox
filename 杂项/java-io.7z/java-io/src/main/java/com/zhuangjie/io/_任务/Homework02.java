package com.zhuangjie.io._任务;

import java.io.*;

public class Homework02 {
    public static void main(String[] args) throws IOException {
        String sourceFilePath = "D:\\system\\文档\\file.txt";
        InputStreamReader isr = new InputStreamReader(new FileInputStream(sourceFilePath), "gbk");
        BufferedReader br = new BufferedReader(isr);
        try {

            String lineStr = "";
            int line_sumber = 1;
            while ((lineStr = br.readLine()) != null) {
                System.out.println((line_sumber++ +""+lineStr));
            }
        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            br.close();
        }

    }
}
