package com.zhuangjie.io;

import org.junit.Test;

import java.io.*;

public class _12_打印流 {
    @Test
    public void main2() throws FileNotFoundException {
        PrintStream printStream = new PrintStream("D:\\system\\文档\\hello.txt");
        System.setOut(printStream);
        System.out.println("你好，主人 ！");
    }

    @Test
    public void main_() throws IOException {


        PrintStream out = System.out;
        PrintWriter printWriter = new PrintWriter(out);
        printWriter.println("写在控制台");
        printWriter.close();


        PrintWriter pw = new PrintWriter(new FileWriter("D:\\system\\文档\\test.txt"));
        pw.write("你好，女人");
        pw.close();


    }
}
