package com.zhuangjie.io;

import org.junit.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class _7_Buffer包装类 {
    @Test
    public void BufferRead() {
        String sourceFilePath = "D:\\system\\文档\\security_authority.sql";
        BufferedReader bufferRead = null;
        try {
            bufferRead = new BufferedReader(new FileReader(sourceFilePath));
            String line_string = "";
            while ((line_string = bufferRead.readLine()) != null) {
                System.out.println(line_string);
            }
        }catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }
}
