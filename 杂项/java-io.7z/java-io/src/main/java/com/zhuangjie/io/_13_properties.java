package com.zhuangjie.io;

import org.junit.Test;

import java.io.*;
import java.util.Properties;

public class _13_properties {
    //properties读
    @Test
    public void test01() throws IOException {
        Properties properties = new Properties();
        properties.load(new FileReader("src\\mysql.properties"));
        String user = properties.getProperty("username");
        System.out.println("用户名："+user);
        String password = properties.getProperty("password");
        System.out.println("密码："+password);

    }
    //写
    @Test
    public void test02() throws IOException {
        Properties properties = new Properties();
        properties.setProperty("charset","utf-8");
        properties.setProperty("nb","牛逼");
        properties.setProperty("zhuangjie","庄杰");
        properties.store(new FileOutputStream("src\\mysql.properties"),"在最上面的注释");
        System.out.println("保存到文件成功！");
    }
}
