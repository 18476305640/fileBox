package com.zhuangjie.io;

import org.junit.Test;

import java.io.*;

public class _8_使用包装类拷贝文件 {
    public static void main(String[] args) {
        String sourceFilePath = "D:\\system\\文档\\文件拷贝.java";
        String newFilePath = "D:\\system\\文档\\buffer拷贝文件.java";
        BufferedReader bufferedReader = null;
        BufferedWriter bufferedWriter = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(sourceFilePath));
            bufferedWriter = new BufferedWriter(new FileWriter(newFilePath));
            String line_data = "";
            while ((line_data = bufferedReader.readLine()) != null) {
                bufferedWriter.write(line_data);
                bufferedWriter.newLine();
            }
        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            try {
                bufferedReader.close();
                bufferedWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }
    @Test
    public void BufferInputStream拷贝文件() {
        String sourceFilePath = "D:\\system\\下载\\VMware-workstation-full-16.2.3-19376536.exe";
        String newFilePath = "D:\\system\\文档\\VM_Clone.exe";
        BufferedInputStream bufferedInputStream = null;
        BufferedOutputStream bufferedOutputStream = null;
        try {
            bufferedInputStream = new BufferedInputStream(new FileInputStream(sourceFilePath));
            bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(newFilePath));
            byte[] bytes = new byte[1024];
            int readLen = 0;
            while ((readLen = bufferedInputStream.read(bytes)) > 0) {
                bufferedOutputStream.write(bytes,0 ,readLen);
            }
        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            try {
                bufferedInputStream.close();
                bufferedOutputStream.close();
            }catch (IOException e) {
                System.out.println(e.getMessage());
            }

        }

    }
}
