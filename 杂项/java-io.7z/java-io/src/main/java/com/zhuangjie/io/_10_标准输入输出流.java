package com.zhuangjie.io;

import org.junit.Test;

import java.io.IOException;
import java.util.Scanner;

public class _10_标准输入输出流 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入:");
        String next = scanner.next();
        System.out.println("你输入的是："+next);
        scanner.close();
    }
}
