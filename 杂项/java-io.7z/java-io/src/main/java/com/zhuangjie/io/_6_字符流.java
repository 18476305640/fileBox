package com.zhuangjie.io;

import org.junit.Test;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class _6_字符流 {
    @Test
    public void write01() {
        String sourceFilePath = "D:\\system\\文档\\文件拷贝.java";
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(sourceFilePath);
            int data = 0;
            while (( data = fileReader.read()) != -1) {
                System.out.print((char) data);
            }

        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            if (sourceFilePath != null) {
                sourceFilePath.getClass();
            }
        }
    }
    //使用数组作缓冲
    @Test
    public void read02() {
        String sourceFilePath = "D:\\system\\文档\\文件拷贝.java";
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(sourceFilePath);
            int readLen = 0;
            char[] chars = new char[128];
            while (( readLen = fileReader.read(chars)) != -1) {
                System.out.print(new String(chars,0,readLen));
            }

        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            if (sourceFilePath != null) {
                sourceFilePath.getClass();
            }
        }
    }

    @Test
    public void write() {
        FileWriter fileWriter = null;
        String sourceFilePath = "D:\\system\\文档\\test.txt";
        try {
            fileWriter = new FileWriter(sourceFilePath,true); //true为追加写
            //参数可以是char 、char[]、String
            fileWriter.write("&Hello,world!",1,5);
            fileWriter.flush();
        }catch (IOException e) {
            System.out.println(e.getMessage());
        }finally {
            try {
                fileWriter.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
