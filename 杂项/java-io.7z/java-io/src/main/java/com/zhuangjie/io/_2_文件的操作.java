package com.zhuangjie.io;

import org.junit.Test;

import java.io.File;
import java.io.IOException;

public class _2_文件的操作 {
    @Test
    public void test() throws IOException {
        File file = new File("D:\\system\\文档\\file0.txt");
        File file_parent = new File(file.getParent());
        if (! file_parent.isDirectory()) {
            file_parent.mkdirs();  //创建文件夹
        }
        if (! file.isFile()) {
            file.createNewFile(); //创建文件
        }
        System.out.println(file.getName()); //获取文件名
        System.out.println(file.getAbsolutePath());//获取文件的绝对路径
        System.out.println(file.getParent()); //获取父目录绝对路径
        if (file.isFile()) {
            System.out.println(file.length()); //文件大小
        }
        System.out.println(file.exists()); //文件是否存在，文件不存在返回false
        System.out.println(file.isFile()); //是否是文件，文件不存在返回falsee
        System.out.println(file.isDirectory()); //是否是文件夹,文件不存在返回false
        file.delete(); //删除空文件夹或文件

    }
}
