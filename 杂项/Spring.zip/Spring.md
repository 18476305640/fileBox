# Spring

## 目录

*   [Spring](#spring-1)

    *   [1.1使用Spring的一个小案例](#11使用spring的一个小案例)

        *   *   [1.1.1下载文件](#111下载文件)

            *   [1.1.2创建一个项目，导入相关jar](#112创建一个项目导入相关jar)

            *   [1.1.3开始编写程序测试](#113开始编写程序测试)

    *   [2.1 IOC的底层原理](#21-ioc的底层原理)

    *   [3.1 IOC操作Bean管理](#31-ioc操作bean管理)

        *   [3.1 XML方式](#31-xml方式)

            *   [3.1.1基于 xml 方式创建对象](#311基于-xml-方式创建对象)

            *   [3.1.2基于 xml 方式注入属性](#312基于-xml-方式注入属性)

        *   [3.2基于注解的方式管理Bean](#32基于注解的方式管理bean)

# Spring

## 1.1使用Spring的一个小案例

#### 1.1.1下载文件

*   去下载Spring包：[https://repo.spring.io/ui/native/release/org/springframework/spring/5.2.6.RELEASE/](https://repo.spring.io/ui/native/release/org/springframework/spring/5.2.6.RELEASE/ "https://repo.spring.io/ui/native/release/org/springframework/spring/5.2.6.RELEASE/")   如何找到的，请打开折叠？

    *   打开[https://repo.spring.io/](https://repo.spring.io/ "https://repo.spring.io/")，然后：

        ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513265675641651326567426.png)

        *   如何找到这个链接的？

            ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513268931021651326893023.png)

下载"spring-5.2.6.RELEASE-dist.zip"，找到除第一个以外的jar包，第一个jar，你需要下载（[https://repo1.maven.org/maven2/commons-logging/commons-logging/1.1.1/commons-logging-1.1.1.jar](https://repo1.maven.org/maven2/commons-logging/commons-logging/1.1.1/commons-logging-1.1.1.jar "https://repo1.maven.org/maven2/commons-logging/commons-logging/1.1.1/commons-logging-1.1.1.jar")）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513274241801651327424006.png)

#### 1.1.2创建一个项目，导入相关jar

创建一个普通的“java项目”然后导入最基本的jar包。

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513278428991651327842795.png)

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513278051831651327804789.png)

#### 1.1.3开始编写程序测试

1.  创建一个com.XXX.XXX 包

2.  在src根下创建一个XXX.xml (\_1\_spring入门案例.xml)

    ```xml
    <?xml version="1.0" encoding="UTF-8"?>
    <beans xmlns="http://www.springframework.org/schema/beans"
           xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
           xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

        <bean id="user" class="com.zjazn.spring._1_spring入门案例.User"></bean>
    </beans>
    ```

3.  创建一个User类，里面随便写一个run方法。

    ```java
    package com.zjazn.spring._1_spring入门案例;

    public class User {
        public void run() {
            System.out.println("不错哟~");
        }
    }

    ```

4.  创建一个测试类,读取xml，利用

    ```java
    package com.zjazn.spring._1_spring入门案例;

    import org.springframework.context.ApplicationContext;
    import org.springframework.context.support.ClassPathXmlApplicationContext;

    public class main {
        public static void main(String[] args) {
            //加载spring配置文件
            ApplicationContext context = new ClassPathXmlApplicationContext("_1_spring入门案例.xml");
            //从中获取生成的对象
            User user = context.getBean("user", User.class);
            //对象的调用测试
            user.run();
        }
    }



    ```

    ![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513294571791651329456473.png)

入门案例[代码>>](https://github.com/18476305640/SourceCodeLearning/tree/master/out/production/mySpring/com/scl/spring/_1_spring%E5%85%A5%E9%97%A8%E6%A1%88%E4%BE%8B "代码>>")

## 2.1 IOC的底层原理

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513323971791651332396974.png)

IOC叫控制反转，把对象创建和对象之间的调用过程，交给Spring进行管理，使用的目的，为了耦合度降低。IOC的底层原理是使用了“XML+工厂设计模式+反射”，比如我们在xml配置了 `<bean id="user" class="com.zjazn.spring._1_spring入门案例.User"></bean>` 我们工厂内部利用xml解析技术，可以得到类路径 `com.zjazn.spring._1_spring入门案例.User` ,这样我们就可以利用反射`Class.forName(className)` 然后调用`clazz.newInstance()`得到工厂模式创建的对象了。

我们可以使用` ApplicationContext context = new ClassPathXmlApplicationContext("_1_spring入门案例.xml");` 得到`ApplicationContext `，其实也可以用`BeanFactory context = new ClassPathXmlApplicationContext("_1_spring入门案例.xml");` 让`BeanFactory `来接收。`ApplicationContext `与`BeanFactory `区别是`BeanFactory `是我们在` context.getBean("user", User.class);` 获取对象的时候才创建的，而`ApplicationContext `是加载xml配置文件后就创建了。且ApplicationContext是BeanFactory的子接口，所以ApplicationContext的功能比BeanFactory更为丰富。

在以下这个示例中

```java
package com.zjazn.spring._1_spring入门案例;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class main {
    public static void main(String[] args) {
        //加载spring配置文件
        ApplicationContext context = new ClassPathXmlApplicationContext("_1_spring入门案例.xml");
        //从中获取生成的对象
        User user = context.getBean("user", User.class);
        //对象的调用测试
        user.run();
    }
}

```

`ClassPathXmlApplicationContext` 可以改为`FileSystemXmlApplicationContext` 区别是`ClassPathXmlApplicationContext` 是根据类路径的(src/...)，而`FileSystemXmlApplicationContext` 是根据盘符的（C:\\..）

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16513623929001651362392683.png)

## 3.1 IOC操作Bean管理

`创建对象` 、`注入属性`

### 3.1 XML方式

#### 3.1.1基于 xml 方式创建对象

```xml
<bean id="user" class="com.scl.spring._1_spring入门案例.User"></bean>
<!--解析
    常用属性是id、clash
    id：是唯一标识 
    clash：是要创建的类的类路径名src下,比如上面
-->
```

然后通过加载配置文件，调用方法即可获取对象。

```java
public class main {
    public static void main(String[] args) {
        //加载spring配置文件
        ApplicationContext context = new ClassPathXmlApplicationContext("com/scl/spring/_1_spring入门案例/_1_spring入门案例.xml");
        //从中获取生成的对象
        User user = context.getBean("user", User.class);
        //对象的调用测试
        user.run();
    }
}
```

注意：创建对象时候，默认也是执行无参数构造方法完成对象创建，如果是有构造函数，请看下面的`基于 `\*\*\*\*`方式注入属性` &#x20;

#### 3.1.2基于 xml 方式注入属性

**方式一**：通过set方法, 要创建对象的类要属性要有set方法。

```java
package com.scl.spring._2_ioc管理bean._1_xml方式._2_注入属性._1_set方法注入;

public class Book {
    private String name;
    private String author;

    public void setName(String name) {
        this.name = name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }


    public void show() {
        System.out.println("name="+name+",author="+author);
    }

}

```

在xml文件中，对象bean标签内为第个有set方法的成员变量配置`property `标签。

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="book" class="com.scl.spring._2_ioc管理bean._1_xml方式._2_注入属性._1_set方法注入.Book">
        <property name="name" value="西游记" ></property>
        <property name="author" value="吴承恩" ></property>
    </bean>
</beans>
```

方式二：通过构造方法

要创建对象的类要属性要有有参的构造函数

```java
public class Book {
    private String name;
    private String author;

    public Book(String name, String author) {
        this.name = name;
        this.author = author;
    }

    public void show() {
        System.out.println("name="+name+",author="+author);
    }

}
```

xml文件中为每个构造函数参数，配置一个`constructor-arg`标签。`constructor-arg`标签里的name属性用index属性代替，值表示的是在构造函数的顺序，如`<constructor-arg index="0" value="《西游记》"></constructor-arg>`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="book" class="com.scl.spring._2_ioc管理bean._1_xml方式._2_注入属性._2_构造方法注入.Book">
        <constructor-arg name="name" value="《西游记》"></constructor-arg>
        <constructor-arg name="author" value="吴承恩"></constructor-arg>
    </bean>
</beans>
```

> 空值的注入和包含特殊字符的注入

```xml
1.一般bean的注入属性：
    <bean id="book" class="com.scl.spring._2_ioc管理bean._1_xml方式._2_注入属性._2_构造方法注入.Book">
            <constructor-arg index="0" value="《西游记》"></constructor-arg>
            <constructor-arg index="1" value="吴承恩"></constructor-arg>
    </bean>

2.空值的注入和包含特殊字符的注入
    <bean id="book" class="com.scl.spring._2_ioc管理bean._1_xml方式._2_注入属性._2_构造方法注入.Book">
            <!--当要注入空值时-->
            <constructor-arg index="0">
                <null />
            </constructor-arg>

            <!--包含特殊字符的注入，使用 <![CDATA[特殊字符]]> -->
            <constructor-arg index="1">
                <value><![CDATA[<<南京>>]]></value>
            </constructor-arg>
    </bean>

```

> 注入属性Bean

利用ref属性为有set方法的成员变量注入Bean。

```xml
<bean name="userDao" class="com.scl.spring._2_ioc管理bean._1_xml方式._2_注入属性._注入属性bean.dao.impl.UserDaoImpl"></bean>
<!--下面使用了ref将userDao的Bean注入了-->
<bean name="UserService" class="com.scl.spring._2_ioc管理bean._1_xml方式._2_注入属性._注入属性bean.service.impl.UserServiceImpl">
      <property name="userDao" ref="userDao" ></property>
</bean>
```

### 3.2基于注解的方式管理Bean

继续整理请转到：[跳转>>](https://github.com/18476305640/ssm/tree/master/src/com/scl/spring "跳转>>")

![](https://cdn.jsdelivr.net/gh/18476305640/typora@master/image/16515592218781651559221719.png)
