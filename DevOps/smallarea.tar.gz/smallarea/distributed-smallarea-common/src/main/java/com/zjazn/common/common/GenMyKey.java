package com.zjazn.common.common;//package com.zjazn.smallarea.common;
//
//import com.baomidou.mybatisplus.core.incrementer.IKeyGenerator;
//import org.springframework.stereotype.Component;
//
//import java.util.Date;
//
//@Component
//public class GenMyKey implements IKeyGenerator {
////    private static int number = 1;
////    private static String tis = new Date().getTime()+"";
//    @Override
//    public String executeSql(String s) {
//        return new Date().getTime()+"";
//    }
//}
