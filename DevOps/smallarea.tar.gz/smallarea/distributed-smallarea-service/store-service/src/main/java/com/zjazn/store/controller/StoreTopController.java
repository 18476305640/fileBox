package com.zjazn.store.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author testjava
 * @since 2021-06-28
 */
@RestController
@RequestMapping("/smallarea/store-top")
public class StoreTopController {

}

