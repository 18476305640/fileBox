package com.zjazn.store.service;

import com.zjazn.store.entity.StoreTop;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author testjava
 * @since 2021-06-28
 */
public interface StoreTopService extends IService<StoreTop> {

}
