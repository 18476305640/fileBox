package com.zjazn.product.mapper;

import com.zjazn.product.entity.GoodsTypeGlobal;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2021-06-22
 */
public interface GoodsTypeGlobalMapper extends BaseMapper<GoodsTypeGlobal> {

}
