package com.zjazn.product.service;

import com.zjazn.product.entity.GoodsStyle;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author testjava
 * @since 2021-07-03
 */
public interface GoodsStyleService extends IService<GoodsStyle> {

}
