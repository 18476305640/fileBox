package com.zjazn.product.service;

import com.zjazn.product.entity.GoodsDetail;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author testjava
 * @since 2021-06-22
 */
public interface GoodsDetailService extends IService<GoodsDetail> {

}
