package com.zjazn.product.service;

import com.zjazn.product.entity.GoodsTop;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author testjava
 * @since 2021-06-29
 */
public interface GoodsTopService extends IService<GoodsTop> {

}
