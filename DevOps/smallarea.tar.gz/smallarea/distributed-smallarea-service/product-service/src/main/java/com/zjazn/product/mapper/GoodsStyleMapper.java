package com.zjazn.product.mapper;

import com.zjazn.product.entity.GoodsStyle;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2021-07-03
 */
public interface GoodsStyleMapper extends BaseMapper<GoodsStyle> {

}
