package com.zjazn.user.mapper;

import com.zjazn.user.entity.Money;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2021-06-17
 */
public interface MoneyMapper extends BaseMapper<Money> {

}
