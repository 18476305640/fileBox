package com.zjazn.cart.mapper;

import com.zjazn.cart.entity.CartDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author testjava
 * @since 2021-07-02
 */
public interface CartDetailMapper extends BaseMapper<CartDetail> {

}
