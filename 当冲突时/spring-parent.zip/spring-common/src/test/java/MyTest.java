import com.zhuangjie.common.RsaUtils;
import org.junit.Test;

public class MyTest {
    private String publicFilePath = "C:\\Users\\zhuangjie\\auth_key\\id_key_rsa.pub";
    private String privateFilePath = "C:\\Users\\zhuangjie\\auth_key\\id_key_rsa";



//    @Test
//    public void test() {
//        try {
//            RsaUtils.generateKey(publicFilePath,privateFilePath,"zjazn",2048);
//        } catch (Exception e) {
//            System.out.printf("Gen errored~");
//            e.printStackTrace();
//        }
//    }
//    @Test
//    public void test02 () {
//        String sepa = java.io.File.separator;
////        System.out.println(sepa);
////        System.out.println(publicKeyPathAndName);
//
////        String path = publicKeyPathAndName.substring(0,publicKeyPathAndName.lastIndexOf(sepa));
////        System.out.println(path);
//        RsaUtils.checkPathExist(publicKeyPathAndName);
//
//
//    }

    @Test
    public void generateKey() throws Exception {
        RsaUtils.generateKey(publicFilePath, privateFilePath, "zjazn", 2048);
    }

    @Test
    public void getPublicKey() throws Exception {
        System.out.println(RsaUtils.getPublicKey(publicFilePath));
    }

    @Test
    public void getPrivateKey() throws Exception {
        System.out.println(RsaUtils.getPrivateKey(privateFilePath));
    }

}
